﻿using CouponAPI.Models;
using CouponAPI.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CouponAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CouponsController : ControllerBase
    {
        private readonly ICouponRepository _couponRepository;

        public CouponsController(ICouponRepository couponRepository)
        {
            _couponRepository = couponRepository;
        }

        [HttpGet]
        public async Task<IEnumerable<Coupon>> GetCoupons()
        {
            return await _couponRepository.Get();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Coupon>> GetCoupons(int id)
        {
            return await _couponRepository.Get(id);
        }

        [HttpPost]
        public async Task<ActionResult<Coupon>>PostCoupons([FromBody] Coupon coupon)
        {
            var newCoupon = await _couponRepository.Create(coupon);
            return CreatedAtAction(nameof(GetCoupons), new { id = newCoupon.Id }, newCoupon);
        }

        [HttpPut]
        public async Task<ActionResult> PutCoupons(int id, [FromBody] Coupon coupon)
        {
            if(id != coupon.Id)
            {
                return BadRequest();
            }

            await _couponRepository.Update(coupon);

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete (int id)
        {
            var couponToDelete = await _couponRepository.Get(id);
            if (couponToDelete == null)
                return NotFound();

            await _couponRepository.Delete(couponToDelete.Id);
            return NoContent();
        }
    }
}
